#!/bin/bash

INSTALL_DIR=`dirname $0`

if hash php 2>/dev/null; then
    # We need this hack because php-config is shipped in php5-dev pkg
    EXTENSION_DIR=`php -r 'echo ini_get("extension_dir");'`
    PHP_MAJOR_VERSION=`php -r 'echo PHP_MAJOR_VERSION;'`
    PHP_MINOR_VERSION=`php -r 'echo PHP_MINOR_VERSION;'`
    PHP_VERSION="${PHP_MAJOR_VERSION}.${PHP_MINOR_VERSION}";

    echo "Detected PHP ${PHP_VERSION} and extension directory: ${EXTENSION_DIR}"
else
    echo "No PHP installation found.";
    echo "Symlink the tideways.so extension and Tideways.php";
    echo "for your PHP version into your extension directory."
    echo "Files have been installed to:"
    echo ""
    echo "  $INSTALL_DIR"
    exit 1
fi

EXTENSION_FILE="$INSTALL_DIR/tideways-php-${PHP_VERSION}.so"

if [ -f "$EXTENSION_DIR/qafooprofiler.so" ]; then
    echo "Tideways Profiler PHP Extension conflicts with the old Qafoo Profiler PHP extension.";
    echo "Please head over to the migration guide to get information on how to migrate.";
    echo "";
    echo "  https://tideways.io/profiler/docs/setup/migrate-tideways";
    echo "";
    echo "If you have questions please write support@tideways.io";
    exit 3
fi

if [ -f "$EXTENSION_FILE" ]; then
    echo "Installing into $EXTENSION_DIR"
    cp $INSTALL_DIR/Tideways.php $EXTENSION_DIR/Tideways.php
    cp $EXTENSION_FILE $EXTENSION_DIR/tideways.so

    echo "Please add the following line to your php.ini file:"
    echo ""
    echo "extension=tideways.so"
    echo ""
    echo "Please restart any webserver or php-fpm process afterwards to make the extension available."
    exit 0
else
    echo "No Tideways Profiler binary found for PHP version ${PHP_VERSION}."
    echo "Please contact support@tidways.io if you need help."
    exit 3
fi
